package operators;

public abstract class Operator {

}
